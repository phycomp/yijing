from glob import glob
from os.path import splitext
from re import findall

CSVs=glob('*.csv')
pttrn用=',(用.：[^,].*?[。？]?),'
pttrn上=',(上.：[^,].*?[。？]?),'
pttrn五=',(.五：[^,].*?[。？]?),'
pttrn四=',(.四：[^,].*?[。？]?),'
pttrn三=',(.三：[^,].*?[。？]?),'
pttrn二=',(.二：[^,].*?[。？]?),'
pttrn初=',(初.：[^,].*?[。？]?),'
pttrn彖=',(彖曰：[^,].*?[。？]?),'
pttrn象=',(象曰：[^,].*?[。？]?),'
allPttrn='|'.join([pttrn用,pttrn上,pttrn五,pttrn四,pttrn三,pttrn二,pttrn初,pttrn彖,pttrn象])
for csv in CSVs:
    base, ext=splitext(csv)
    allHexa=[]
    fout=open('%sHexa%s'%(base, ext), 'w')
    data=open(csv).read()
    for HEXA in findall(allPttrn, data):
        for hexa in HEXA:
            if hexa:allHexa.append(hexa)
    fout.write('\n'.join(allHexa)+'\n')
    fout.close()
